﻿namespace RemoteReg
{
    partial class FormRemoteReg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setRegToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getFolderFilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getFileVersionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBoxGetFileVer = new System.Windows.Forms.TextBox();
            this.textBoxRegPath = new System.Windows.Forms.TextBox();
            this.textBoxRegName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxGetFolderVer = new System.Windows.Forms.TextBox();
            this.checkBoxSd = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxRegVal = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonNumber = new System.Windows.Forms.RadioButton();
            this.radioButtontext = new System.Windows.Forms.RadioButton();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 115);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(615, 173);
            this.listBox1.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.runToolStripMenuItem,
            this.setRegToolStripMenuItem,
            this.getFolderFilesToolStripMenuItem,
            this.getFileVersionToolStripMenuItem,
            this.clearToolStripMenuItem,
            this.openFolderToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(643, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.runToolStripMenuItem.Text = " Run Registry Check";
            this.runToolStripMenuItem.Click += new System.EventHandler(this.runToolStripMenuItem_Click);
            // 
            // setRegToolStripMenuItem
            // 
            this.setRegToolStripMenuItem.Name = "setRegToolStripMenuItem";
            this.setRegToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.setRegToolStripMenuItem.Text = "Set Reg";
            this.setRegToolStripMenuItem.Click += new System.EventHandler(this.setRegToolStripMenuItem_Click);
            // 
            // getFolderFilesToolStripMenuItem
            // 
            this.getFolderFilesToolStripMenuItem.Name = "getFolderFilesToolStripMenuItem";
            this.getFolderFilesToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.getFolderFilesToolStripMenuItem.Text = "GetFolderFiles";
            this.getFolderFilesToolStripMenuItem.Click += new System.EventHandler(this.getFolderFilesToolStripMenuItem_Click);
            // 
            // getFileVersionToolStripMenuItem
            // 
            this.getFileVersionToolStripMenuItem.Name = "getFileVersionToolStripMenuItem";
            this.getFileVersionToolStripMenuItem.Size = new System.Drawing.Size(90, 20);
            this.getFileVersionToolStripMenuItem.Text = "GetFile Version";
            this.getFileVersionToolStripMenuItem.Click += new System.EventHandler(this.getFileVersionToolStripMenuItem_Click);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // openFolderToolStripMenuItem
            // 
            this.openFolderToolStripMenuItem.Name = "openFolderToolStripMenuItem";
            this.openFolderToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.openFolderToolStripMenuItem.Text = "Open Folder";
            this.openFolderToolStripMenuItem.Click += new System.EventHandler(this.openFolderToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 434);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(643, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(109, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(109, 17);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(32, 28);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // textBoxGetFileVer
            // 
            this.textBoxGetFileVer.Location = new System.Drawing.Point(144, 58);
            this.textBoxGetFileVer.Name = "textBoxGetFileVer";
            this.textBoxGetFileVer.Size = new System.Drawing.Size(216, 20);
            this.textBoxGetFileVer.TabIndex = 4;
            this.textBoxGetFileVer.Text = "c:\\temp\\c.txt";
            // 
            // textBoxRegPath
            // 
            this.textBoxRegPath.Location = new System.Drawing.Point(141, 307);
            this.textBoxRegPath.Name = "textBoxRegPath";
            this.textBoxRegPath.Size = new System.Drawing.Size(327, 20);
            this.textBoxRegPath.TabIndex = 5;
            // 
            // textBoxRegName
            // 
            this.textBoxRegName.Location = new System.Drawing.Point(70, 333);
            this.textBoxRegName.Name = "textBoxRegName";
            this.textBoxRegName.Size = new System.Drawing.Size(187, 20);
            this.textBoxRegName.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 310);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Reg Path LocalMachine:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 333);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Reg key";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "File Version Path :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Folder Version Path :";
            // 
            // textBoxGetFolderVer
            // 
            this.textBoxGetFolderVer.Location = new System.Drawing.Point(144, 84);
            this.textBoxGetFolderVer.Name = "textBoxGetFolderVer";
            this.textBoxGetFolderVer.Size = new System.Drawing.Size(216, 20);
            this.textBoxGetFolderVer.TabIndex = 10;
            this.textBoxGetFolderVer.Text = "c:\\temp";
            // 
            // checkBoxSd
            // 
            this.checkBoxSd.AutoSize = true;
            this.checkBoxSd.Location = new System.Drawing.Point(475, 58);
            this.checkBoxSd.Name = "checkBoxSd";
            this.checkBoxSd.Size = new System.Drawing.Size(115, 17);
            this.checkBoxSd.TabIndex = 12;
            this.checkBoxSd.Text = "הפעלת שערי דלק";
            this.checkBoxSd.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(266, 338);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Reg Value";
            // 
            // textBoxRegVal
            // 
            this.textBoxRegVal.Location = new System.Drawing.Point(328, 336);
            this.textBoxRegVal.Name = "textBoxRegVal";
            this.textBoxRegVal.Size = new System.Drawing.Size(140, 20);
            this.textBoxRegVal.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtontext);
            this.groupBox1.Controls.Add(this.radioButtonNumber);
            this.groupBox1.Location = new System.Drawing.Point(487, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(144, 103);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // radioButtonNumber
            // 
            this.radioButtonNumber.AutoSize = true;
            this.radioButtonNumber.Location = new System.Drawing.Point(35, 24);
            this.radioButtonNumber.Name = "radioButtonNumber";
            this.radioButtonNumber.Size = new System.Drawing.Size(62, 17);
            this.radioButtonNumber.TabIndex = 0;
            this.radioButtonNumber.TabStop = true;
            this.radioButtonNumber.Text = "Number";
            this.radioButtonNumber.UseVisualStyleBackColor = true;
            // 
            // radioButtontext
            // 
            this.radioButtontext.AutoSize = true;
            this.radioButtontext.Checked = true;
            this.radioButtontext.Location = new System.Drawing.Point(35, 61);
            this.radioButtontext.Name = "radioButtontext";
            this.radioButtontext.Size = new System.Drawing.Size(46, 17);
            this.radioButtontext.TabIndex = 1;
            this.radioButtontext.TabStop = true;
            this.radioButtontext.Text = "Text";
            this.radioButtontext.UseVisualStyleBackColor = true;
            // 
            // FormRemoteReg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 456);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxRegVal);
            this.Controls.Add(this.checkBoxSd);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxGetFolderVer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxRegName);
            this.Controls.Add(this.textBoxRegPath);
            this.Controls.Add(this.textBoxGetFileVer);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormRemoteReg";
            this.Text = "Remote Reg";
            this.Load += new System.EventHandler(this.FormRemoteReg_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ToolStripMenuItem setRegToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxGetFileVer;
        private System.Windows.Forms.ToolStripMenuItem getFileVersionToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxRegPath;
        private System.Windows.Forms.TextBox textBoxRegName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem openFolderToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem getFolderFilesToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxGetFolderVer;
        private System.Windows.Forms.CheckBox checkBoxSd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxRegVal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtontext;
        private System.Windows.Forms.RadioButton radioButtonNumber;
    }
}

