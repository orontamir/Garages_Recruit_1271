﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Collections;
using System.Diagnostics;


 


    public static class ClsApi
    {        
        
        private static Object LockSync = new object ();
        public static void Handle_Log(string FileNm,string Sinf)
        {

            lock (LockSync)
            {
                TextWriter tw = new StreamWriter(FileNm.Replace ("\\","") +".txt", true);
                // write a line of text to the file
                tw.WriteLine(DateTime.Now + ", " + Sinf);
                // close the stream
                tw.Close();
            }

        }
    
    





    }
