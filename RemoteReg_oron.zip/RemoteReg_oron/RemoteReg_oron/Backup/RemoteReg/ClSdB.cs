﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using OracleInProcServer;

    public static class  ClSdB
    {
        private static OraSession  OraSess =  new OraSessionClassClass ();
        public static OraDatabase OraDb;
        public static OraDynaset OraDynSt;

        public static string DbName = "delekos", Pwd = "comm_center/cc1234";        
        public static bool DbConnect()
        {
                  
            try
            {
                OraDb = (OraDatabase)OraSess.get_OpenDatabase (DbName, Pwd, 0);
                GetStIps("FUEL", false);
                


    

                 
                return true;
            }
            catch (Exception er)
            {
                ClsApi.Handle_Log("Log","DbConnect Err : " + er.Message ); 
                return false;
            }
        }
         
        public static void Dbdisconnect()
        {            
            OraDb.Close();
            OraDb = null;
        }
        public static void GetStIps(string Dest, bool  is_sd)
        {
            Object Obj = new object();      
            string StrsqlSt = " select g.m_atar, ";
            if (Dest.Equals("Delek"))
            {
                StrsqlSt += "g.ktovet_tcpip ";
                StrsqlSt += " from delek_tachana_main g  where g. m_atar < 9000 and g.status_reshuma=1 ";
              
                
                

            }
            else if (Dest.Equals("Bo"))
            {
                StrsqlSt += "g.ktovet_tcpip_bo ";
                StrsqlSt += " from delek_tachana_main g  where g. m_atar < 9000 and g.status_reshuma=1   ";

            }
            else if (Dest.Equals("Kupa"))
            {

                StrsqlSt += "  g.ktovet_kupa_1,g.ktovet_kupa_2 from delek_tachana_main g  where g. m_atar < 9000 and g.status_reshuma=1 and  g.ktovet_kupa_1 is not null ";
                
            }
            if (is_sd )
            {
                StrsqlSt += " and g.m_atar in (select m_tachana from all_tachanot where status_reshuma=0 and operation_type ='01' ) ";
            }
            StrsqlSt += " and  exists (select  1 from delek_tachana_ack da where da.tar_ack_machshev> sysdate -7 and da.m_atar=g.m_atar ) ";
            StrsqlSt += "order by g.m_atar  ";
            OraDynSt = (OraDynaset)OraDb.get_CreateDynaset(StrsqlSt, 0, ref Obj);
            return;

        }

    }

