﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OracleInProcServer;
using Microsoft.Win32; 
using System.IO;
using System.Diagnostics;
namespace RemoteReg
{
    public partial class FormRemoteReg : Form
    {
        public FormRemoteReg()
        {
            InitializeComponent();
        }

        private void runToolStripMenuItem_Click(object sender, EventArgs e)
        {
             
            GetReg();
        }
        private void SetReg()
        {
            string RegFileLof = "RegFileLog";
            string Sip = "10.1.15.5"; 
            string Sst;
            string sRegVal="";
            //char[] Token=  new char [1];
            //Token[0]=char.Parse (",");                              
            string sBaseKey = @"SOFTWARE\PointOfSale\PumpSrv\GeneralParam";
            sBaseKey = textBoxRegPath.Text;
            string sBaseName = "AllowAuthOnNonRequest";
            sBaseName = textBoxRegName.Text;
            //string sBaseVal = "dword:00000000";
            ClSdB.GetStIps(comboBox1.Text, checkBoxSd.Checked);
            
            while (!ClSdB.OraDynSt.EOF)
            {
                Sst = ((OracleInProcServer.OraField)ClSdB.OraDynSt[0]).Value.ToString();
                Sip = ((OracleInProcServer.OraField)ClSdB.OraDynSt[1]).Value.ToString() ;            
                try
                {
            RegistryKey baseKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, Sip);
                   


            
                    using (RegistryKey testSettings = baseKey.OpenSubKey(sBaseKey,RegistryKeyPermissionCheck.ReadWriteSubTree,System.Security.AccessControl.RegistryRights.FullControl))
                    {
                        // Delete the non-secure password value.
                        //testSettings.DeleteValue("password");
                        int i_val =0;
                        //if(int.TryParse(textBoxRegVal.Text,out i_val))
                        if (radioButtonNumber.Checked)
                        {
                            i_val = int.Parse(textBoxRegVal.Text);
                             testSettings.SetValue(sBaseName, i_val,RegistryValueKind.DWord);
                        }
                        else{
                             testSettings.SetValue(sBaseName, textBoxRegVal.Text,RegistryValueKind.String);
                        }

                       
                        listBox1.Items.Insert(0, Sip);
                        ClsApi.Handle_Log(RegFileLof, "Update " + Sip);
                        Application.DoEvents();                    
                    }
                }
                catch (Exception er)
                {

                    listBox1.Items.Insert(0, Sst + "," + Sip + "," + sRegVal + " , " + er.Message);
                    ClsApi.Handle_Log(RegFileLof, Sst + "," + Sip + "," + sRegVal + " , " + er.Message);
                }


                ClSdB.OraDynSt.MoveNext();
            }                    
             

        }


        private void GetReg()
        {
            string Sip; string Sst;                        
            string sBaseName = "";            
            char[] Token=  new char [1];
            Token[0]=char.Parse (",");                              
            sBaseName = textBoxGetFileVer.Text;
            ClSdB.GetStIps(comboBox1.Text,checkBoxSd.Checked);                                            
            while (!ClSdB.OraDynSt.EOF)
            {
                Sst = ((OracleInProcServer.OraField)ClSdB.OraDynSt[0]).Value.ToString();
                Sip = ((OracleInProcServer.OraField)ClSdB.OraDynSt[1]).Value.ToString() ;
                GetVal(Sip, textBoxRegPath.Text, Sst, textBoxRegName.Text, textBoxRegName.Text);
                Application.DoEvents();             
                ClSdB.OraDynSt.MoveNext();
            }
            MessageBox.Show ("complete"); 
        }
        private void GetFileVer()
        {
            string Sip; string Sst;            
            string sBaseName = "";
            char[] Token = new char[1];
            Token[0] = char.Parse(",");
            FileInfo the_fl;            
            sBaseName = textBoxGetFileVer.Text;
            ClSdB.GetStIps(comboBox1.Text, checkBoxSd.Checked);
            
            while (!ClSdB.OraDynSt.EOF)
            {
                Sst = ((OracleInProcServer.OraField)ClSdB.OraDynSt[0]).Value.ToString();
                Sip = ((OracleInProcServer.OraField)ClSdB.OraDynSt[1]).Value.ToString();
                string MyPath = "\\\\" + Sip + "\\c\\Office\\fcc\\FCC.exe";
                listBox1.Items.Insert(0, MyPath);
                try
                {
                    MyPath = "\\\\" + Sip + textBoxGetFileVer.Text.Replace (":","");
                        the_fl = new FileInfo(MyPath);
                        if (the_fl.Exists)
                        { ClsApi.Handle_Log("File Att", Sst + "," + Sip + "," + the_fl.Name + " ,LastWriteTime, " + the_fl.LastWriteTime.ToShortDateString()
                            + " ,CreationTime, " + the_fl.CreationTime.ToShortDateString());
                        }
                        else 
                        { ClsApi.Handle_Log("File Att", Sst + "," + Sip + "," + the_fl.Name + " , file not found"  ); }
                }
                catch (Exception Er)
                {
                    ClsApi.Handle_Log("File Att", Sst + "," + Sip + ",GetFileVer," + Er.Message);
                }
                Application.DoEvents();
                ClSdB.OraDynSt.MoveNext();
            }
            MessageBox.Show("complete");
        }
        private void GetFolderFileVer()
        {
            string Sip; string Sst;            
            string sBaseName = "";
            char[] Token = new char[1];
            Token[0] = char.Parse(",");
            FileInfo the_fl;
            FileVersionInfo fl;
            sBaseName = textBoxGetFileVer.Text;
            ClSdB.GetStIps(comboBox1.Text, checkBoxSd.Checked);          
            while (!ClSdB.OraDynSt.EOF)
            {
                Sst = ((OracleInProcServer.OraField)ClSdB.OraDynSt[0]).Value.ToString();
                Sip = ((OracleInProcServer.OraField)ClSdB.OraDynSt[1]).Value.ToString();
                string MyPath = "";
                try
                {
                        MyPath = "\\\\" + Sip + textBoxGetFolderVer;
                        listBox1.Items.Insert(0, MyPath);
                        string[] fileEntries = Directory.GetFiles(MyPath);
                        foreach(string fileName in fileEntries)
                        {                            
                            the_fl = new FileInfo(fileName);
                            fl = FileVersionInfo.GetVersionInfo(MyPath);
                            if (the_fl.Exists)
                            { 
                                ClsApi.Handle_Log("File Att", Sst + "," + Sip + "," + the_fl.Name + " ,LastWriteTime, " + the_fl.LastWriteTime.ToShortDateString() + " ,CreationTime, " + the_fl.CreationTime.ToShortDateString()); 
                                ClsApi.Handle_Log("File Att", Sst + "," + Sip + "," + the_fl.Name + " ,FileVersion, " + fl.FileVersion );
                            }
                            else
                            { 
                                ClsApi.Handle_Log("File Att", Sst + "," + Sip + "," + the_fl.Name + " , file not found"); 
                            }
                        }


                }catch (Exception Er)                
                {
                    ClsApi.Handle_Log("Log", Sst + "," + Sip + "," + Er.Message );
                }
                Application.DoEvents();

                ClSdB.OraDynSt.MoveNext();
            }
            MessageBox.Show("complete");
        }
        private void GetVal(string MySip, string MysBaseKey, string MySst, string MysBaseName, string  FlNAme)
        {
            string sRegVal = "";
            try
            {
                RegistryKey baseKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.LocalMachine, MySip);
                //RegistryKey baseKey = RegistryKey.OpenRemoteBaseKey(RegistryHive.ClassesRoot, MySip);
                using (RegistryKey testSettings = baseKey.OpenSubKey(MysBaseKey, true))
                {
                    sRegVal = testSettings.GetValue(MysBaseName).ToString();
                    listBox1.Items.Insert(0, MySip);
                    Application.DoEvents();
                    ClsApi.Handle_Log(FlNAme, MySst + "," + MySip + "," + MysBaseName + " , " + sRegVal);
                }
            }
            catch (Exception er)
            {

                listBox1.Items.Insert(0, MySst + "," + MySip + "," + sRegVal + " , " + er.Message);
                ClsApi.Handle_Log(MysBaseName, MySst + "," + MySip + "," + sRegVal + " , " + er.Message);
            }

        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear(); 
        }

        private void FormRemoteReg_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Delek");
            comboBox1.Items.Add("Bo");
            comboBox1.Items.Add("Kupa");
            comboBox1.Text = "Delek";
            ClSdB.DbConnect();

        }

        private void setRegToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Inactive option");            
            SetReg();
        }

        private void getFileVersionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetFileVer();
        }

        private void openFolderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", Application.StartupPath );

        }

        private void getFolderFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GetFolderFileVer();
        }
    }
}
